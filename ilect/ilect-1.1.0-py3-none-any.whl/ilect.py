# frontend/ilect-cl/public/ilect.py is a duplicate of
# workbook/workbook-image/assets/ilect/ilect.py
# frontend/ilect-cl/public/ilect.py is being kept in consideration of the
# old notebooks that download this file, but will eventually be removed.
# Until then, edit both manually for consistency when modifying.

import json
from pathlib import Path
from pprint import pprint
import sys

import pandas as pd
import requests
from requests import exceptions as errors
from functools import wraps

url = "https://cl.ilect.io"
token = str()

multiple_submissions = {}


def init(token, url=None):
    """
    Set token for an assignment.

    Parameters
    ----------

    token: str
        A token which you got from the ilect-colab website.

    url: str
        A url which you want to use. This is only for developers.
    """

    if type(token) is not str:
        raise TypeError('"token" must be str type.')

    globals()["token"] = token

    if url is not None:
        globals()["url"] = url

    print("Your token has been updated.")


def download_df(debug=False, outdir=None):
    """
    Download dataframes for an assignment which you are going to submit.

    Paramaters
    ----------

    debug: bool
        Turn it True when you want to check the more detailed result.
    outdir: Path | str | None
        Root directory to save the files.
    """

    if outdir is None:
        outdir = Path.cwd()
    else:
        outdir = Path(outdir)

    outdir.mkdir(exist_ok=True)

    try:

        response = requests.get(
            url + "/api/Dataset/Download/?token={}".format(token),
            timeout=10,
        )

        code = response.status_code

        if 500 > code >= 400:
            print("Your token is invalid. Please check or refresh it and" " retry.")
            return

        if not 300 > code >= 200:
            print(
                "Unknown error has occured. Please contact to the system"
                " administrator."
            )
            return

        datasets = json.loads(response.content)

        for dataset in datasets:

            if dataset["url"] != "":

                response = requests.get(dataset["url"])

                if not 300 > response.status_code >= 200:
                    print(
                        "At least, one of resource servers is unavalible."
                        " Please contact to the system administrator."
                    )

                with open(outdir / dataset["filename"], "wb") as fout:
                    print(
                        "Writing file {}... ".format(outdir / dataset["filename"]),
                        end="",
                    )
                    fout.write(response.content)
                    print("Done")

        if 500 > code >= 400:
            print("Your token is invalid. Please check or refresh it and" " retry.")
            return

        if not 300 > code >= 200:
            print(
                "Unknown error has occured. Please contact to the system"
                " administrator."
            )
            return

    except errors.Timeout:
        print(
            "The server did not respond. Please check your connection status"
            " and retry."
        )
        return

    except errors.InvalidURL:
        print(
            "The valid url is needed. Check your URL and please specify with"
            ' the set_url function. Do not put "/" in the end of the url.'
        )
        return

    except KeyError as err:
        print(
            "The server did not respond appropriately. Please contact to the"
            " system administrator."
        )

        if debug:
            print("------<Exception-Info>------")
            pprint(err.__dict__)

        return

    except requests.exceptions.HTTPError as err:
        print(
            "Unknown error has occured. Please contact to the system" " administrator."
        )

        if debug:
            print("------<Exception-Info>------")
            pprint(err.__dict__)

        return

    finally:
        if debug and "response" in locals():
            print("------<Response-Info>------")
            pprint(response.__dict__)


def error_handling(func):
    @wraps(func)
    def inner(*args, **kwargs):
        try:
            code = func(*args, **kwargs)

            if code == 429:
                print("You requested too many times. Please retry later.")

            elif code in (401, 403):
                print("Your token is invalid. Please check or refresh it and" " retry.")

            elif code == 201:
                print("Your submission has been successfully accepted.")

            else:
                print(
                    "Unknown error has occured. Please contact to the system"
                    " administrator."
                )

        except errors.Timeout:
            print(
                "The server did not respond. Please check your connection status"
                " and retry."
            )

        except errors.InvalidURL:
            print(
                "The valid url is needed. Check your URL and please specify with"
                ' the set_url function. Do not put "/" in the end of the url.'
            )

        except requests.exceptions.HTTPError:
            print(
                "Unknown error has occured. Please contact to the system"
                " administrator."
            )

    return inner


@error_handling
def submit(df, comment: str = None, debug: bool = False) -> int:
    """
    Submit your data to the ilect-colab server.

    Paramaters
    ----------

    df: str
        A dataframe which you want to submit.

    comment:
        A comment which you want to submit.

    debug: bool
        Turn it True when you want to check the more detailed result.
    """

    if type(df) not in (str, pd.core.frame.DataFrame):
        raise TypeError('"df" must be str or pandas dataframe type.')

    if type(df) is pd.core.frame.DataFrame:
        df = df.to_csv()

    data = {"submitted_csv": df, "token": token, "comment": comment}

    response = requests.post(
        url + "/api/Submission/Submit/",
        timeout=10,
        json=data,
    )

    if response.headers.get("status") == "expired":
        print("This assignment is pass the due date.")

    if debug and "response" in locals():
        print("------<Response-Info>------")
        pprint(response.__dict__)

    if in_colab() and not debug:
        submit_notebook_colab(response.json()["id"])

    return response.status_code


def set_answer(idx, answer):
    """
    When you want to submit multiple answers at once, you need to set answers with
    indices.

    Parameters
    ----------

    idx: int, str
        Index to the answer.

    answer: int, str
        The content of the answer.
    """

    if type(idx) not in (int, str):
        raise TypeError('"idx" must be int or str')

    if type(answer) not in (int, str):
        raise TypeError('"answer" must be int or str')

    multiple_submissions[str(idx)] = str(answer)

    print("Your answer is successfully set.")


def submit_all(comment: str = None, debug: bool = False):
    """
    When you want to submit multiple answers, submit all answers.

    Parameters
    ----------

    comment: str
        Comment that you want to put.

    debug: bool
        Only for developers.
    """

    return submit(df=json.dumps(multiple_submissions), comment=comment, debug=debug)


@error_handling
def submit_notebook_colab(submission_id):
    # Load the notebook JSON.
    from google.colab import _message

    try:
        nb = _message.blocking_request("get_ipynb", request="", timeout_sec=20)
        new_notebook = nb["ipynb"]
    except TypeError:
        # Silently fail
        pass
    except Exception:
        return 500
    else:
        response = requests.post(
            url + f"/api/Submission/{submission_id}/FileSubmission/",
            files={"file": json.dumps(new_notebook)},
            data={"filename": "submission.ipynb", "token": token},
        )

        return response.status_code


def in_colab() -> bool:
    return "google.colab" in sys.modules
